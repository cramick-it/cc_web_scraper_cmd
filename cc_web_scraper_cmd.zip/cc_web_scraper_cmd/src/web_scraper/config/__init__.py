from .logging_conf import setup_logging

__version__ = '1.0.0'

__all__ = [
    'setup_logging'
]