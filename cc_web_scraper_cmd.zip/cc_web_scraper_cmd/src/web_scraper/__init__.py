from web_scraper.services import EyewikiService, MedicalNewsTodayService

__all__ = ['EyewikiService', 'MedicalNewsTodayService']