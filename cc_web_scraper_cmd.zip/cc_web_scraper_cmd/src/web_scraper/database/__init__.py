from .client import save_page

__version__ = '1.0.0'

__all__ = [
    'save_page'
]